package services;


import db.IcesiDatabase;
import entities.Estudiante;

import javax.ejb.Stateless;
import javax.ws.rs.*;
import java.util.ArrayList;

@Stateless
@Path("estudiante")
public class EstudianteServices {

    @Path("insert")
    @POST
    @Consumes("application/json")
    @Produces("application/json")
    public Estudiante insertEstudiante(Estudiante estudiante){
        IcesiDatabase icesiDatabase = new IcesiDatabase();
        icesiDatabase.insertEstudiante(estudiante);
        icesiDatabase.closeConnection();
        return estudiante;
    }

    //Obtener lista de estudiantes
    @GET
    @Path("getall")
    @Produces("application/json")
    public ArrayList<Estudiante> getAllEstudiantes(){
        IcesiDatabase icesiDatabase = new IcesiDatabase();
        ArrayList<Estudiante> estudiantes = icesiDatabase.getAllEstudiantes();
        return estudiantes;
    }


    //Obtener un elemento por id
    @GET
    @Path("byid/{id}")
    @Produces("application/json")
    public Estudiante getEstudianteByID(@PathParam("id") String id){
        IcesiDatabase icesiDatabase = new IcesiDatabase();
        Estudiante estudiante = icesiDatabase.getEstudianteByID(id);
        return estudiante;
    }

}
