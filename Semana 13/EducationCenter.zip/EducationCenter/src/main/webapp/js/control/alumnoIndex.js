const titulo = document.getElementById("titulo");
const alumnoNombre = document.getElementById("alumnoNombre");
const localStorage = window.localStorage;

//Recuperar info
const id = localStorage.getItem("id");
const nombre = localStorage.getItem("nombre");
const codigo = localStorage.getItem("codigo");

document.addEventListener("DOMContentLoaded", init);

function init() {
    titulo.innerHTML = nombre;
    alumnoNombre.innerHTML = nombre;
}