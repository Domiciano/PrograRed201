const titulo = document.getElementById("titulo");
const idIT = document.getElementById("idIT");
const nombreIT = document.getElementById("nombreIT");
const codigoIT = document.getElementById("codigoIT");
const registroBTN = document.getElementById("registroBTN");
const alumnosContenedor = document.getElementById("alumnosContenedor");

const localStorage = window.localStorage;

var alumnos = [];
var usuario = {};


registroBTN.addEventListener( "click",  registrar );


function registrar(){

    var id = idIT.value;
    var nombre = nombreIT.value;
    var codigo = codigoIT.value;

    console.log(id);
    console.log(nombre);
    console.log(codigo);

    //alumnosContenedor.innerHTML = id+":"+nombre+":"+codigo;
    /*
    titulo.innerHTML = nombre;

    alumnos.push(nombre+" "+codigo);

    console.log(alumnos);

    alumnosContenedor.innerHTML = "";
    for(let i=0 ; i<alumnos.length ; i++){
        alumnosContenedor.innerHTML += "<p>"+alumnos[i]+"</p>";
    }

    usuario["id"] = id;
    usuario["nombre"] = nombre;
    usuario["codigo"] = codigo;

    console.log(usuario);
    */

    var alumnoObj = new Alumno(id, nombre, codigo);
    console.log(alumnoObj);
    alumnoObj.alfa = "ALFA";
    console.log(alumnoObj);


    var parrafo = document.createElement("p");
    var enlace = document.createElement("a");
    //<a></a>
    enlace.href = "#";
    //<a href="#"></a>
    enlace.id = alumnoObj.id;
    //<a href="#" id="idest"></a>
    enlace.innerHTML = alumnoObj.nombre;
    //<a href="#" id="idest">Andres Andrade</a>
    parrafo.appendChild(enlace);
    //<p><a href="#" id="idest">Andres Andrade</a></p>

    alumnosContenedor.appendChild(parrafo);


    var enlaceHTML = document.getElementById(alumnoObj.id);
    enlaceHTML.addEventListener("click", function(event){
        //alert(alumnoObj.nombre);
        event.preventDefault();

        localStorage.setItem("id", alumnoObj.id);
        localStorage.setItem("nombre", alumnoObj.nombre);
        localStorage.setItem("codigo", alumnoObj.codigo);

        window.location.href = "/src/main/webapp/alumnoIndex.html";

    });

}