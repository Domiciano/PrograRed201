class Alumno{

    constructor(id, nombre, codigo){
        this.id = id;
        this.nombre = nombre;
        this.codigo = codigo;
        Object.seal(this);
    }

    //metodos
    toJson(){
        //to JSON
        return JSON.stringify(this);
    }

}