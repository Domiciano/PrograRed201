class Materia{

    constructor(id, nombre, NRC) {
        this.id = id;
        this.nombre = nombre;
        this.NRC = NRC;
        Object.seal(this);
    }

    toJson(){
        return JSON.stringify(this);
    }

}