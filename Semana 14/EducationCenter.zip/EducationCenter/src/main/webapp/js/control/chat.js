const messageBox = document.getElementById("messageBox");
const messageBtn = document.getElementById("messageBtn");
const messageContainer = document.getElementById("messageContainer");
const socket = new WebSocket("ws://localhost:8080/EducationCenter/server");

document.addEventListener("DOMContentLoaded", init);

function init() {


    socket.onopen = function () {

    };

    socket.onmessage = function (event) {
        let recibido = event.data.toString();
        let parrafo = document.createElement("p");
        parrafo.innerHTML = recibido;
        messageContainer.appendChild(parrafo);
    };

    socket.onclose = function () {

    };


}

messageBtn.addEventListener("click", function () {
    var msg = messageBox.value;
    messageBox.value = "";
    socket.send(msg);
});
