const titulo = document.getElementById("titulo");
const alumnoNombre = document.getElementById("alumnoNombre");
const matid = document.getElementById("matid");
const matnombre = document.getElementById("matnombre");
const matnrc = document.getElementById("matnrc");
const registrarBTN = document.getElementById("registrarBTN");
const materiasContenedor = document.getElementById("materiasContenedor");
const agregarBTN = document.getElementById("agregarBTN");
const matriculasContenedor = document.getElementById("matriculasContenedor");

const localStorage = window.localStorage;

//Recuperar info
const alumno = JSON.parse( localStorage.getItem("alumno") );

document.addEventListener("DOMContentLoaded", init);

function init() {
    titulo.innerHTML = alumno.nombre;
    alumnoNombre.innerHTML = alumno.nombre;

    loadMaterias();

}

function loadMaterias() {
    materiasContenedor.innerHTML = "";

    var xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        var objects = JSON.parse(xhr.responseText);

        for(let i=0 ; i<objects.length ; i++){
            let mMateria = objects[i];
            let opcion = document.createElement("option");
            opcion.value = mMateria.id;
            opcion.innerHTML = mMateria.nombre;
            materiasContenedor.appendChild(opcion);
        }

        loadMatriculas(alumno.id);

    };
    xhr.open("GET", "api/materias/getall");
    xhr.send();


}

registrarBTN.addEventListener("click", function () {

    var id = matid.value;
    var nombre = matnombre.value;
    var nrc = matnrc.value;
    var materia = new Materia(id, nombre, nrc);

    var json = materia.toJson();
    console.log(json);

    var xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        loadMaterias();
    };
    xhr.open("POST", "api/materias/insert");
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(json);

});

agregarBTN.addEventListener("click", function () {

    var matID = materiasContenedor.value;
    var estID = alumno.id;

    var xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        //Cargar la materias matriculadas del estudiante.
        console.log("POST Done");
        loadMatriculas(alumno.id);
    };
    xhr.open("POST", "api/materias/register/" + matID + "/" + estID);
    xhr.send();


});

function loadMatriculas(id) {

    matriculasContenedor.innerHTML = "";

    var xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        console.log(xhr.responseText);
        var objects = JSON.parse( xhr.responseText );

        for(let i=0 ; i<objects.length ; i++){
            let nMateria = objects[i];
            let li = document.createElement("li");
            li.innerHTML = nMateria.nombre;
            matriculasContenedor.appendChild(li);
        }

    };
    xhr.open("GET", "api/estudiante/listmaterias/"+id);
    xhr.send();

}