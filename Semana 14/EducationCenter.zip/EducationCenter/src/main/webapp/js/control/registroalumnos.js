const titulo = document.getElementById("titulo");
const idIT = document.getElementById("idIT");
const nombreIT = document.getElementById("nombreIT");
const codigoIT = document.getElementById("codigoIT");
const registroBTN = document.getElementById("registroBTN");
const alumnosContenedor = document.getElementById("alumnosContenedor");

const localStorage = window.localStorage;

var alumnos = [];
var usuario = {};


registroBTN.addEventListener( "click",  registrar );


function registrar(){

    var id = idIT.value;
    var nombre = nombreIT.value;
    var codigo = codigoIT.value;

   var alumno = new Alumno(id, nombre, codigo);
   //transformar a JSON
    var json = alumno.toJson();
    console.log(json);

    var xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        console.log("POST Done");
        loadAllAlumnos();
    };
    xhr.open("POST", "api/estudiante/insert");
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(json);


}

function loadAllAlumnos() {
    alumnosContenedor.innerHTML = "";

    var xhr = new XMLHttpRequest();
    xhr.onloadend = function () {
        console.log(xhr.responseText);
        var objects = JSON.parse(xhr.responseText);
        console.log(objects);

        for(let i=0 ; i<objects.length ; i++){
            var nAlumno = objects[i];
            createLinkAlumno(nAlumno);
        }

    };
    xhr.open("GET", "api/estudiante/getall");
    xhr.send();

}

document.addEventListener("DOMContentLoaded", function () {
    //Cuando se carga toda la pagina
    loadAllAlumnos();
});

function createLinkAlumno(nAlumno){
    var nParrafo = document.createElement("p");
    var nElance = document.createElement("a");
    nElance.href = "#";
    nElance.id = nAlumno.id;
    nElance.innerHTML = nAlumno.nombre;
    nParrafo.appendChild(nElance);
    alumnosContenedor.appendChild(nParrafo);

    var HTMLEnlace = document.getElementById(nAlumno.id);
    HTMLEnlace.addEventListener("click", function (event) {
        event.preventDefault();
        localStorage.setItem("alumno", JSON.stringify(nAlumno) );
        window.location.href = "alumnoIndex.html";
    });

}