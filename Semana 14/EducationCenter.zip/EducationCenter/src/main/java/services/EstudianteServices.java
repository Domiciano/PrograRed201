package services;


import db.ConnectionPool;
import db.IcesiDatabase;
import entities.Estudiante;
import entities.Materia;

import javax.ejb.Stateless;
import javax.ws.rs.*;
import java.util.ArrayList;

@Stateless
@Path("estudiante")
public class EstudianteServices {

    @Path("insert")
    @POST
    @Consumes("application/json")
    @Produces("application/json")
    public Estudiante insertEstudiante(Estudiante estudiante){
        IcesiDatabase icesiDatabase = ConnectionPool.getAvailableConnection();
        icesiDatabase.insertEstudiante(estudiante);
        icesiDatabase.setBusy(false);
        return estudiante;
    }

    //Obtener lista de estudiantes
    @GET
    @Path("getall")
    @Produces("application/json")
    public ArrayList<Estudiante> getAllEstudiantes(){
        IcesiDatabase icesiDatabase = ConnectionPool.getAvailableConnection();
        ArrayList<Estudiante> estudiantes = icesiDatabase.getAllEstudiantes();
        icesiDatabase.setBusy(false);
        return estudiantes;
    }


    //Obtener un elemento por id
    @GET
    @Path("byid/{id}")
    @Produces("application/json")
    public Estudiante getEstudianteByID(@PathParam("id") String id){
        IcesiDatabase icesiDatabase = ConnectionPool.getAvailableConnection();
        Estudiante estudiante = icesiDatabase.getEstudianteByID(id);
        icesiDatabase.setBusy(false);
        return estudiante;
    }

    //QUe nos entregue las materias que tiene matriculadas un estudiante determinado


    @GET
    @Path("listmaterias/{estid}")
    @Produces("application/json")
    public ArrayList<Materia> getMateriasOfEstudiante(@PathParam("estid") String id){

        IcesiDatabase icesiDatabase = ConnectionPool.getAvailableConnection();
        ArrayList<Materia> arreglo = icesiDatabase.getMateriasOfEstudiante(id);
        icesiDatabase.setBusy(false);
        return arreglo;

    }

}
